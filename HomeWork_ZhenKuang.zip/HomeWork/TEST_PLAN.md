# E-Primer Test Plan

## 1. Scope
- Validate the main E-Primer page and its core functionality.
- Verify input handling, output rendering, highlight behavior, and statistics updates.
- Confirm the page handles line breaks and HTML-sensitive characters safely.

## 2. Test Types
- Functional UI tests: verify app behavior through the browser.
- Regression tests: ensure previously fixed behaviors keep working.
- Accessibility/usability tests: verify form labels, button text, and focus behavior.
- Boundary/negative tests: empty input, punctuation, mixed case, and HTML-sensitive content.

### Not a high priority
- Performance/stress testing: the app is a simple static page with very small input.
- Back-end/API tests: there is no server-side component in this app.

## 3. Functional UI Test Cases

The automated UI tests are implemented with Playwright in separate files:
- `tests/pageobjects/eprimerPage.js` for the page object
- `tests/eprimer.spec.js` for the test scripts

### 3.1 Page-level checks
- Page loads successfully.
- The textarea, button, and statistics elements are visible.
- The button triggers result generation.

### 3.2 Word counting and output rendering
- Empty input: word count = 0, discouraged count = 0, possible violations = 0.
- Normal text: output matches input, no highlights, correct word count.
- Discouraged words: highlights in red, discouraged count increments.
- Apostrophe violations: words containing "'s" highlight in blue and increment possible violations.
- New lines: output is wrapped in separate paragraph tags for each line break.
- HTML-sensitive text: `<` and `>` are escaped in output and do not render as markup.

### 3.3 Case and punctuation handling
- Mixed case discouraged words like "IS" are still flagged.
- Discouraged words adjacent to punctuation such as "be," or "are." are still detected.
- Input containing multiple spaces and punctuation still counts words correctly.

## 4. Expected Tests with Pass/Fail Criteria
- Enter `I am happy.` and click the button.
  - Pass: word count = 3, discouraged words = 1, `am` highlighted red.
- Enter `This is Chris's book.`
  - Pass: word count = 4, possible violations = 1, `Chris's` highlighted blue.
- Enter `Hello\nWorld`.
  - Pass: output contains two paragraphs, word count = 2.
- Enter `<script>alert(1)</script>`.
  - Pass: output displays literal `<` and `>` as text, not as HTML markup.
- Enter nothing and click button.
  - Pass: all counters remain 0 and output is empty or blank paragraph.

## 5. Additional Recommended Tests
- Accessibility: label association, button role, focus order.
- Exploratory: input with emoji or non-English characters.
- Regression: ensure future refactorings preserve highlight and count behavior.
- Usability: make sure repeated button clicks update output correctly.
