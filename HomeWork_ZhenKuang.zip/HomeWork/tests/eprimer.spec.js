/**
 * Playwright test suite for the E-Primer application.
 *
 * These tests cover the primary user flows for the page:
 * - loading the app and displaying core UI elements
 * - checking empty input behavior
 * - identifying discouraged words and apostrophe-based warnings
 * - preserving newline rendering in output
 * - escaping HTML-sensitive characters in the rendered result
 */
import { test, expect } from '@playwright/test';
import { EPrimerPage } from './pageobjects/eprimerPage.js';

let primer;

test.beforeEach(async ({ page }) => {
  primer = new EPrimerPage(page);
  await primer.goto();
  await expect(primer.checkButton).toBeVisible();
});

test('loads the application and shows core elements', async () => {
  await expect(primer.textarea).toBeVisible();
  await expect(primer.checkButton).toBeVisible();
  await expect(primer.wordCount).toHaveText('');
});

test('empty input shows zero counts', async () => {
  await primer.enterText('');
  await primer.clickCheck();
  await expect(primer.wordCount).toHaveText('0');
  await expect(primer.discouragedWordCount).toHaveText('0');
  await expect(primer.possibleViolationCount).toHaveText('0');
});

test('flags discouraged words and updates counts', async () => {
  await primer.enterText('I am happy');
  await primer.clickCheck();
  await expect(primer.wordCount).toHaveText('3');
  await expect(primer.discouragedWordCount).toHaveText('1');
  await expect(primer.possibleViolationCount).toHaveText('0');
  await expect(primer.output).toContainText('am');
  await expect(primer.output.locator('.ep_violation')).toHaveCount(1);
});

test('flags apostrophe-based possible violations', async () => {
  await primer.enterText("Chris's book is here");
  await primer.clickCheck();
  await expect(primer.wordCount).toHaveText('4');
  await expect(primer.discouragedWordCount).toHaveText('1');
  await expect(primer.possibleViolationCount).toHaveText('1');
  await expect(primer.output.locator('.ep_warning')).toHaveCount(1);
});

test('preserves new lines as separate paragraphs', async () => {
  await primer.enterText('Hello\nWorld');
  await primer.clickCheck();
  const outputHtml = await primer.getOutputHtml();
  expect(outputHtml).toContain('</p><p>');
  await expect(primer.wordCount).toHaveText('2');
});

test('escapes HTML-sensitive characters in output', async () => {
  await primer.enterText('<script>alert(1)</script>');
  await primer.clickCheck();
  const outputHtml = await primer.getOutputHtml();
  expect(outputHtml).toContain('&lt;script&gt;alert(1)&lt;/script&gt;');
});
