/**
 * Page object model for the E-Primer application.
 *
 * This class encapsulates interactions with the main app page, including:
 * - loading the local HTML page
 * - entering text into the E-Primer textarea
 * - clicking the check button
 * - reading the generated output and statistics
 *
 * The page object keeps locators and helper methods in one place for cleaner tests.
 */
import path from 'path';
import { fileURLToPath } from 'url';

export class EPrimerPage {
  constructor(page) {
    this.page = page;
    this.textarea = page.locator('#inputtext');
    this.checkButton = page.locator('#CheckForEPrimeButton');
    this.output = page.locator('#eprimeoutput');
    this.wordCount = page.locator('#wordCount');
    this.discouragedWordCount = page.locator('#discouragedWordCount');
    this.possibleViolationCount = page.locator('#possibleViolationCount');
  }

  async goto() {
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = path.dirname(__filename);
    const appPath = path.join(__dirname, '..', '..', 'eprimer.html');
    const candidates = [
      `file://${appPath}`,
      'https://testpages.eviltester.com/apps/e-primer/',
    ];

    let lastError;
    for (const url of candidates) {
      try {
        await this.page.goto(url, { waitUntil: 'domcontentloaded', timeout: 20000 });
        if (await this.page.locator('#inputtext').count()) {
          return;
        }
      } catch (error) {
        lastError = error;
      }
    }

    throw lastError || new Error(`Unable to load the E-Primer application from ${candidates.join(' or ')}`);
  }

  async enterText(text) {
    await this.textarea.fill(text);
  }

  async clickCheck() {
    await this.checkButton.click();
  }

  async getOutputHtml() {
    return this.output.innerHTML();
  }

  async getWordCount() {
    return this.wordCount.textContent();
  }

  async getDiscouragedWordCount() {
    return this.discouragedWordCount.textContent();
  }

  async getPossibleViolationCount() {
    return this.possibleViolationCount.textContent();
  }
}
