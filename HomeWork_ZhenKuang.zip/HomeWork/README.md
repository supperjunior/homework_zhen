# E-Primer Test Project

This workspace contains a small Playwright-based test suite for the E-Primer app used in the SDET interview homework.

## Project purpose

The goal is to validate the main E-Primer page behavior described in the homework:

- page loads successfully
- textarea and button are available
- empty input produces zero counts
- discouraged words are detected and highlighted
- apostrophe-based possible violations are flagged
- output preserves paragraph breaks for new lines
- HTML-sensitive characters are escaped in output

## Files

- `eprimer.html` – local copy of the app page
- `eprime.js` – app logic for E-Primer behavior
- `TEST_PLAN.md` – the project test plan
- `tests/eprimer.spec.js` – Playwright test cases
- `tests/pageobjects/eprimerPage.js` – page object model for the app

## Running the tests

From the project root, run:

```bash
npm test -- --reporter=line
```

## Notes

The live site at `https://testpages.eviltester.com/apps/e-primer/` has changed over time. The page object prefers the repository-local app for stable automation and falls back to the live site if needed.

This keeps the tests deterministic while still allowing validation against the current published version of the app.
